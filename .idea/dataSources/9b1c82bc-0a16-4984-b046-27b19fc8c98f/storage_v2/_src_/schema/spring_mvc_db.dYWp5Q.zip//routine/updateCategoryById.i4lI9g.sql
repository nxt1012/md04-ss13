create
    definer = root@localhost procedure updateCategoryById(IN pName varchar(50), IN pStatus bit, IN pId int)
begin
    update category set name = pName, status = pStatus where id = pId;
end;

