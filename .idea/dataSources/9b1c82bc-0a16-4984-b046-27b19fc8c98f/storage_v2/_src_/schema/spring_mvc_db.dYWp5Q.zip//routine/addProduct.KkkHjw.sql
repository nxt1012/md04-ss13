create
    definer = root@localhost procedure addProduct(IN pName varchar(255), IN pPrice float, IN pImage text,
                                                  IN pCategoryId int, IN pStatus bit)
begin
    insert into product (name, price, image, category_id, status) VALUES (pName, pPrice, pImage, pCategoryId, pStatus);
end;

