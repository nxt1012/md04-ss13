create
    definer = root@localhost procedure deleteCategoryById(IN pId int)
begin
    delete from category where id = pId;
end;

