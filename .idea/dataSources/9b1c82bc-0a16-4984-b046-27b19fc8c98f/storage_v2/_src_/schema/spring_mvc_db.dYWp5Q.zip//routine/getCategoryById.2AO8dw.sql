create
    definer = root@localhost procedure getCategoryById(IN pId int)
begin
    select * from category where id = pId;
end;

